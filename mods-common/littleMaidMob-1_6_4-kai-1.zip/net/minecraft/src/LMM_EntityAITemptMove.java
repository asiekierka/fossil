package net.minecraft.src;

import net.minecraft.entity.ai.EntityAIBase;

public class LMM_EntityAITemptMove extends EntityAIBase {

	@Override
	public boolean shouldExecute() {
		// TODO Auto-generated method stub
		return false;
	}

}
